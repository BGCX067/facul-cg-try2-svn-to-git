#include <GL/glut.h>
#include <stdlib.h>
#include <stdio.h>
#include "fmod.h"
#include "fmod_errors.h"

/*
 * Constantes de estados do jogo
 */
#define INICIO 0
#define JOGANDO 1
#define FIM 2
#define FECHA 3
/*
 * Constantes relacionadas ao tipo de objeto e quantidade
 */
#define MAXOBJETOS 8

#define QUAD 0
#define QUADSIZE 50

#define TRI 1
#define TRISIZE 100

#define POL 2
#define POLSIZE 150

#define RET 3
#define RETSIZE 100
/*
 * Constante tempo do jogo
 */
#define TEMPOJOGOSEG 30

/*
 * Tamanho do pegador
 */
#define SIZE_PEG 200
/*
 * Passos que os objetos que o usuario deve pegar andam por itera��o de tempo
 */
#define GRAVIDADE 10
/*
 * Passos que o pegador anda por itera��o de tempo
 */
#define PASSOS 10
/*
 * adapta��o para usar variaveis booleanas em c
 */
#define bool int
#define true 1
#define false 0

/*
 * Altura para view port de escrita
 */
#define Altura_View_Escrita 30

/*
 * variaveis para manipula��o do tempo
 */
long freq, start, stop, tempo;

/*
 * Defini��o de tipo para estrutura do objeto
 */
typedef struct {
	int Obj;
	bool em_tela;
	GLfloat x;
	GLfloat y;
	bool colidiu;
	int somou;
} Objeto;

/*
 * Vetor de objetos que ser�o colocados em tela
 */
Objeto VetorObjetos[MAXOBJETOS];

/*
 * Inteiro que verifica a posi��o do pegador
 */
GLint controley = 'q';

/*
 * pontua��o
 */
int pontuacao = 0;
/*
 * Variavel para verificar se esta utilizando joystick ou keyboard
 */
bool Joystick = false;

/*
 * Variavel para posicao do pegador
 */
GLfloat x_pegador = 1023.0f;
GLfloat y_pegador = 0.0f;

/*
 * Variavel para defini��o do estado
 */
int estado = 0;
/*
 * Valores do tamanho da tela
 */
GLint x_janela;
GLint y_janela;

void Testa_tempo();
/*
 * Executa som
 */
void tocaMusica() {
	FSOUND_SAMPLE *samp1 = 0; //cria um ponteiro para armazenar o som em mem�ria
	//    Seleciona a sa�da de audio
	FSOUND_SetOutput(FSOUND_OUTPUT_DSOUND);

	//    Sele��o do driver
	FSOUND_GetOutput(); // indentifica o tipo de saida
	FSOUND_GetMixer(); // indentifica o mixer
	FSOUND_SetDriver(0); // seta o driver de som que vai ser usado

	//    Inicializando o FMOD
    FSOUND_Init(44100, 32, FSOUND_INIT_GLOBALFOCUS); // se o valor do FSOUND_Init for 0 execute o tratamento de erro


	// Carrengando o Sample
	// PCM,44,100 Hz, 32 Bit, Mono ou uma mp3 ou outros formatos suportados pelo fmod
	samp1 = FSOUND_Sample_Load(FSOUND_UNMANAGED, "paranoid.ogg",
			FSOUND_NORMAL | FSOUND_HW2D, 0, 0);

	// Aqui fala qual maneira o sample ira tocar caso falhe excute o tratamento de erro
	FSOUND_Sample_SetMode(samp1, FSOUND_LOOP_NORMAL);// o loop normal toca a musica continuamente ate o programa fechar

	// Aqui sera tocado o sample ,caso falhe, execute o tratamento de erro
	FSOUND_PlaySound(FSOUND_FREE, samp1);

}

void Reshape(int x, int y){
	x_janela = x;
	y_janela = y;
}
/*
 * faz a escrita de um texto em determinado local da tela e com uma letra definida
 */
void DesenhaTexto(char *string, int posicaox, int posicaoy, void * texto) {
	glPushMatrix();
	glRasterPos2f(posicaox, posicaoy);
	while (*string)
		glutBitmapCharacter(texto, *string++);
	glPopMatrix();
}
/*
 * Calcula a pontuacao de a cordo com a forma geometrica e faz os calculos
 */
void calculaPontuacao(int qual_forma) {

	switch (qual_forma) {
	case QUAD: {
		pontuacao += 2;
	};break;
	case TRI: {
		pontuacao += 1;
	};break;
	case POL: {
		pontuacao -= 2;
	};break;
	case RET: {
		pontuacao -= 2;
	};break;
	}
}
/*
 * Escreve pontos e tempo no estado jogando
 */
void escreve_pontos_tempo() {
	char guarda[20];
	glColor3f(0.0f, 0.0f, 0.0f);
	DesenhaTexto("Pontos: ", 20, 300,GLUT_BITMAP_HELVETICA_18);
	itoa(pontuacao, guarda, 10);
	DesenhaTexto(guarda, 150, 300,GLUT_BITMAP_HELVETICA_18);
	DesenhaTexto("Tempo: ", 500, 300,GLUT_BITMAP_HELVETICA_18);
	itoa(tempo, guarda, 10);
	DesenhaTexto(strcat(guarda, " seg"), 630, 300,GLUT_BITMAP_HELVETICA_18);
}
/*
 * Coloca valores na variavel de controle do pegador a partir do joystick
 */
void joysticke(unsigned int buttonMask, int x, int y, int z) {
	controley = y;
}
/*
 * Inicializa glut
 */
void init(void) {
	glClearColor(0.0, 0.0, 0.0, 1.0); // cor de fundo
	glOrtho(0, 1024, 0, 1024, -1, 1); // modo de projecao ortogonal
}
/*
 * Coloca valores na variavel de controle do pegador a partir do keyboard
 */
void key(unsigned char bottom, int x, int y) {
	controley = bottom;
}
/*
 * Inicializa valores dos objetos no inicio do programa
 */
void initValoresObjetos() {
	int contador;
	for (contador = 0; contador < MAXOBJETOS; contador++) {
		VetorObjetos[contador].em_tela = false;
		VetorObjetos[contador].colidiu = false;
	}

}
/*
 * desenha quadrado verde claro
 */
void desenha_quadrado(Objeto Posicao) {
	glBegin(GL_QUADS);
	glColor3f(0.5f, 1.0f, 0.5f);
	glVertex2i(Posicao.x, Posicao.y);
	glVertex2i(Posicao.x + QUADSIZE, Posicao.y);
	glVertex2i(Posicao.x + QUADSIZE, Posicao.y + QUADSIZE);
	glVertex2i(Posicao.x, Posicao.y + QUADSIZE);
	glEnd();
}
/*
 * desenha triangulo roxo
 */
void desenha_Triangulo(Objeto Posicao) {
	glBegin(GL_TRIANGLES);
	glColor3f(0.5f, 0.3f, 0.7f);
	glVertex2i(Posicao.x, Posicao.y);
	glVertex2i(Posicao.x, Posicao.y + TRISIZE);
	glVertex2i(Posicao.x + TRISIZE, (Posicao.y + Posicao.y + TRISIZE) / 2);
	glEnd();
}
/*
 * desenha retangulo verde claro
 */
void desenha_Retangulo(Objeto Posicao) {
	glBegin(GL_QUADS);
	glColor3f(0.5f, 1.0f, 0.5f);
	glVertex2i(Posicao.x, Posicao.y);
	glVertex2i(Posicao.x + RETSIZE, Posicao.y);
	glVertex2i(Posicao.x + RETSIZE, Posicao.y + QUADSIZE);
	glVertex2i(Posicao.x, Posicao.y + QUADSIZE);
	glEnd();
}
/*
 * Desenha poligono de 5 lados vermelho
 */
void desenha_Poligon(Objeto Posicao) {

	glBegin(GL_POLYGON);
	glColor3f(1.0f, 0.0f, 0.0f);
	glVertex2i(Posicao.x, Posicao.y);
	glVertex2i(Posicao.x, Posicao.y + QUADSIZE);
	glVertex2i(Posicao.x + RETSIZE, Posicao.y + QUADSIZE);
	glVertex2i(Posicao.x + POLSIZE, (Posicao.y + Posicao.y + QUADSIZE) / 2);
	glVertex2i(Posicao.x + RETSIZE, Posicao.y);
	glEnd();
}
/*
 * Escolhe qual objeto vai ser desenhado
 */
void DesenhaObj(int QuemDesenhar) {
	switch (VetorObjetos[QuemDesenhar].Obj) {
	case TRI: {
		desenha_Triangulo(VetorObjetos[QuemDesenhar]);
	};break;
	case QUAD: {
		desenha_quadrado(VetorObjetos[QuemDesenhar]);
	};break;
	case POL: {
		desenha_Poligon(VetorObjetos[QuemDesenhar]);
	};break;
	case RET: {
		desenha_Retangulo(VetorObjetos[QuemDesenhar]);
	};break;
	}
}
/*
 * Faz o desenho do pegador
 */
void desenhaPegador() {
	glBegin(GL_LINES);
	glColor3f(0.5f, 0.6f, 0.7f);

	glVertex2i(x_pegador, y_pegador);
	glVertex2i(x_pegador, y_pegador + SIZE_PEG);

	glVertex2i(x_pegador - 2, y_pegador);
	glVertex2i(x_pegador - 2, y_pegador + SIZE_PEG);

	glVertex2i(x_pegador - 4, y_pegador);
	glVertex2i(x_pegador - 4, y_pegador + SIZE_PEG);

	glVertex2i(x_pegador - 6, y_pegador);
	glVertex2i(x_pegador - 6, y_pegador + SIZE_PEG);

	glVertex2i(x_pegador - 8, y_pegador);
	glVertex2i(x_pegador - 8, y_pegador + SIZE_PEG);

	glVertex2i(x_pegador - 10, y_pegador);
	glVertex2i(x_pegador - 10, y_pegador + SIZE_PEG);

	glVertex2i(x_pegador - 12, y_pegador);
	glVertex2i(x_pegador - 12, y_pegador + SIZE_PEG);

	glVertex2i(x_pegador - 14, y_pegador);
	glVertex2i(x_pegador - 14, y_pegador + SIZE_PEG);

	glVertex2i(x_pegador - 16, y_pegador);
	glVertex2i(x_pegador - 16, y_pegador + SIZE_PEG);

	glVertex2i(x_pegador, y_pegador);
	glVertex2i(x_pegador - 30, y_pegador);
	glVertex2i(x_pegador, y_pegador + SIZE_PEG);
	glVertex2i(x_pegador - 30, y_pegador + SIZE_PEG);

	glVertex2i(x_pegador, y_pegador - 2);
	glVertex2i(x_pegador - 30, y_pegador - 2);
	glVertex2i(x_pegador, y_pegador + SIZE_PEG + 2);
	glVertex2i(x_pegador - 30, y_pegador + SIZE_PEG + 2);

	glVertex2i(x_pegador, y_pegador - 4);
	glVertex2i(x_pegador - 30, y_pegador - 4);
	glVertex2i(x_pegador, y_pegador + SIZE_PEG + 4);
	glVertex2i(x_pegador - 30, y_pegador + SIZE_PEG + 4);

	glVertex2i(x_pegador, y_pegador - 6);
	glVertex2i(x_pegador - 30, y_pegador - 6);
	glVertex2i(x_pegador, y_pegador + SIZE_PEG + 6);
	glVertex2i(x_pegador - 30, y_pegador + SIZE_PEG + 6);

	glVertex2i(x_pegador, y_pegador - 8);
	glVertex2i(x_pegador - 30, y_pegador - 8);
	glVertex2i(x_pegador, y_pegador + SIZE_PEG + 8);
	glVertex2i(x_pegador - 30, y_pegador + SIZE_PEG + 8);

	glEnd();
}
/*
 * Desenha um quadrado base para ser desenhado as letras
 */
void fundoViewPortLetras() {
	glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
	glVertex2i(0, 0);
	glVertex2i(0, 1024);
	glVertex2i(1024, 1024);
	glVertex2i(1024, 0);

	glEnd();
}
/*
 * Verifica colis�o para calcular os pontos
 */
void Verifica_Colisao() {
	int contador;
	for (contador = 0; contador < MAXOBJETOS; contador++) {
		if (VetorObjetos[contador].colidiu) {
			if (VetorObjetos[contador].somou == 1) {
				calculaPontuacao(VetorObjetos[contador].Obj);
				(VetorObjetos[contador].somou)++;
			}
		}
	}
}
/*
 *  inicializa variaveis de um objeto
 */
void initOBJ(Objeto * PosicaoInicial, int OBJ) {
	PosicaoInicial->x = (rand() % 100) * -1;
	PosicaoInicial->y = rand() % 950;
	PosicaoInicial->em_tela = true;
	PosicaoInicial->Obj = OBJ;
	PosicaoInicial->colidiu = false;
	PosicaoInicial->somou = 0;
}
/*
 * Inicializa um objeto com uma posicao de objetos fora da tela no vetor
 */
void inicializaNovo(int LugarVazio) {
	int OBJ;
	OBJ = rand() % 4;
	initOBJ(&VetorObjetos[LugarVazio], OBJ);
}
/*
 *  inicializa objetos e desenha objetos na tela
 */
void ViewPortObjetos() {
	int contador;
	for (contador = 0; contador < MAXOBJETOS; contador++) {
		if (!VetorObjetos[contador].em_tela) {
			inicializaNovo(contador);
		}
	}
	for (contador = 0; contador < MAXOBJETOS; contador++) {
		if (VetorObjetos[contador].em_tela) {
			DesenhaObj(contador);
		}
	}
	desenhaPegador();
}
/*
 *  verifica se objetos colidiram com o pegador
 */
void Colisao() {
	int contador;
	for (contador = 0; contador < MAXOBJETOS; contador++) {
		if (((VetorObjetos[contador].x >= 1019 && VetorObjetos[contador].x <= 1030) && (VetorObjetos[contador].y >= y_pegador + 10 && VetorObjetos[contador].y <= y_pegador + SIZE_PEG - 10))||
			((VetorObjetos[contador].x >= 1019 && VetorObjetos[contador].x <= 1030) && (VetorObjetos[contador].y+QUADSIZE >= y_pegador + 10 && VetorObjetos[contador].y +QUADSIZE<= y_pegador + SIZE_PEG - 10))){
			VetorObjetos[contador].colidiu = true;
			VetorObjetos[contador].somou++;
		}
	}
}
/*
  Faz desenhos durante o jogo
 */
void Jogando(){
	glClear(GL_COLOR_BUFFER_BIT);
	glColor3f(1.0f, 1.0f, 1.0f);
	glViewport(0, 0, x_janela,Altura_View_Escrita);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	fundoViewPortLetras();
	escreve_pontos_tempo();
	glViewport(0,Altura_View_Escrita, x_janela, y_janela-Altura_View_Escrita);
	ViewPortObjetos();
}
/*
 *  Faz desenhos da tela inicial
 */
void Inicio(){
	glClear(GL_COLOR_BUFFER_BIT);

	glViewport(0,y_janela - Altura_View_Escrita-50,x_janela ,Altura_View_Escrita+50);
	glMatrixMode(GL_PROJECTION);
	glColor3f(1.0f, 1.0f, 1.0f);
	DesenhaTexto("A - Para Joystick", 3, 490 ,GLUT_BITMAP_HELVETICA_18);
	DesenhaTexto("D - Para Keyboard", 712, 490,GLUT_BITMAP_HELVETICA_18);
	DesenhaTexto("<Enter> - Para Comecar", 300, 20,GLUT_BITMAP_HELVETICA_18);
	glViewport(0,0,x_janela ,y_janela - Altura_View_Escrita-50);
	if(Joystick){
		glColor3f(0.0f, 0.0f, 1.0f);
		glBegin(GL_QUADS);
		glVertex2i(0, 0);
		glVertex2i(0, 1024);
		glVertex2i(512, 1024);
		glVertex2i(512, 0);
		glEnd();
		glColor3f(1.0f, 0.0f, 0.0f);
		glBegin(GL_QUADS);
		glVertex2i(512, 0);
		glVertex2i(512, 1024);
		glVertex2i(1024, 1024);
		glVertex2i(1024, 0);
		glEnd();
		glColor3f(1.0f, 0.0f, 0.0f);
		DesenhaTexto("Utilizar Joystick", 50, 510 ,GLUT_BITMAP_TIMES_ROMAN_24);
	}else{
		glColor3f(1.0f, 0.0f, 0.0f);
		glBegin(GL_QUADS);
		glVertex2i(0, 0);
		glVertex2i(0, 1024);
		glVertex2i(512, 1024);
		glVertex2i(512, 0);
		glEnd();
		glColor3f(0.0f, 0.0f, 1.0f);
		glBegin(GL_QUADS);
		glVertex2i(512, 0);
		glVertex2i(512, 1024);
		glVertex2i(1024, 1024);
		glVertex2i(1024, 0);
		glEnd();
		glColor3f(1.0f, 0.0f, 0.0f);
		DesenhaTexto("Utilizar Keyboard", 572, 510,GLUT_BITMAP_TIMES_ROMAN_24);
		 }

}
/*
 * Desenha um quadrado escrito dentro "<enter> - para fechar"
 */
void fim(){
	glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0, 1.0f);
	glVertex2i(200, 200);
	glVertex2i(200, 2*y_janela-200 );
	glVertex2i(2*x_janela-200, 2*y_janela-200);
	glVertex2i(2*x_janela-200, 200);
	glEnd();
	glColor3f(0.0f, 0.0, 0.0f);
	DesenhaTexto("<Enter> - Para Fechar", 320, 500,GLUT_BITMAP_HELVETICA_18);
}
/*
 * fun��o display principal. Dependendo do estado do jogo, chama um display
 * especifico. E desenha algo especifico
 * Os estados possiveis s�o:
 * Inicio: onde o usario inicia o jogo
 * Jogando
 * Fim: onde o usuario decide se quer finalizar o jogo
 */
void display(void) {
    switch(estado){
    case INICIO:{
    	Inicio();
    };break;
    case JOGANDO:{
    	Jogando();
    };break;
    case FIM:{
    	fim();
    };break;
    }
}
/*
 * Seleciona movimento do pegador utilizando o joystick
 */
void Controle_Joy(){
	if (controley < 80) // tecla w
	{
		y_pegador += PASSOS;
	}
	if (controley > -80) //tecla s
	{
		y_pegador -= PASSOS;
	}
}
/*
 * Seleciona movimento do pegador utilizando o keyboard
 */
void Controle_Key(){
	switch(controley){
	case'W':
	case'w':
	{
		y_pegador += PASSOS;
	};break;
	case'S':
	case's':
	{
		y_pegador -= PASSOS;
	};break;
	}
}

/*
 * verifica se as figuras ainda est�o em tela. Caso n�o estejam, sao
 * posicionadas novamente para o inicio da tela.
 */
void verifica_fora_tela(){
	int contador;
	for (contador = 0; contador < MAXOBJETOS; contador++) {
		if (VetorObjetos[contador].x > 1030) {
			VetorObjetos[contador].em_tela = false;
		}
	}
}
/*
 * Escolhe se vai chamar a fun��o que verifica os valores de sinais do joystick
 * ou as teclas do keyboard
 */
void escolhe_joy_key(){
	if(Joystick){
		glutJoystickFunc(joysticke, 2);
	}else{
		 glutKeyboardFunc(key);
		 }
}
/*
 * Faz os objetos que o usuario deve pegar mudarem de posi��o pela
 * tela
 */
void AdicionaGravidade(){
	int contador;
	for (contador = 0; contador < MAXOBJETOS; contador++) {
		VetorObjetos[contador].x += GRAVIDADE + contador;
	}
}
/*
 * Verifica se o pegador esta na tela
 * e faz o alter��es da posi��o do pegador na tela com joystick ou keyboard
 */
void Trabalha_com_pegador(){
	if (y_pegador == -10.0f) {
		y_pegador = 0.0f;
	} else {
		if (y_pegador == 830.0f) {
			y_pegador = 820.0f;
		} else {
			if(Joystick){
				Controle_Joy();
			}else{
				  Controle_Key();
				 }
		}
	}
	controley = 'q';
}
/*
 * Faz as verifica��es do jogo por exemplo:
 * controle de colis�o
 * verifica objetos em tela
 * manipula pegador na tela
 * adiciona passos nos objetos do jogo
 */
void Timer_Jogando(int value) {
	if(Joystick){
	glutForceJoystickFunc();
	}
	Trabalha_com_pegador();
	AdicionaGravidade();
	verifica_fora_tela();
	Colisao();
	Verifica_Colisao();
	glFlush();
	glutPostRedisplay();
	Testa_tempo();
}
/*
 * Seleciona controle ou joytick ou inicia o jogo atraves da intera��o do teclado,
 */
void FazMovimento_inicio(){
	switch(controley){
		case 'A':
		case 'a':{
			Joystick = true;
		};break;
		case 'D':
		case 'd':{
			Joystick = false;
		};break;
		case 13:{
			estado = JOGANDO;
		};break;
	}
	controley = 'q';
}
/*
 * finaliza o jogo a partir do teclado
 */
void FazMovimento_fim(){
	switch(controley){
		case 13:{
			estado = FECHA;
		};break;
	}
	controley = 'q';
}
/*
 * timer que fica verificando a escolha do usuario entre utilizar joystick ou keyboard
 */
void Timer_Inicio(int value) {
	FazMovimento_inicio();
	if(estado == INICIO){
		glutTimerFunc(10, Timer_Inicio, 1);
	}else{
		 tocaMusica();
		 QueryPerformanceCounter((LARGE_INTEGER *) &start);
		 escolhe_joy_key();
		 glutTimerFunc(10, Timer_Jogando, 1);
		 }
	glFlush();
	glutPostRedisplay();
}
/*
 *  Faz verifica��o se o usuario deseja finalizar o jogo
 */
void Timer_fim(int value) {
	FazMovimento_fim();
	if(estado != FECHA){
		glutTimerFunc(10, Timer_fim, 1);
	}else{
		  exit(0);
		 }
	glFlush();
	glutPostRedisplay();
}
/*
 * Verifica se o tempo de jogo ja foi concluido, definido inicialmente em 30 segundos
 * se finalizar o tempo chama o timer fim
 */
void Testa_tempo(){
	QueryPerformanceCounter((LARGE_INTEGER *) &stop);
	tempo = ((double) stop - (double) start) / (double) freq;

	if (tempo <= TEMPOJOGOSEG) {
		glutTimerFunc(10, Timer_Jogando, 1);
	}else{
			estado = FIM;
			glutTimerFunc(10, Timer_fim, 1);
		 }

}

// funcao principal
int main(int argc, char** argv) {
	QueryPerformanceFrequency((LARGE_INTEGER *) &freq);
	glutInit(&argc, argv); // inicializa o glut
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB); // especifica o uso de cores e buffers
	glutInitWindowSize(512, 512); // especifica as dimensoes da janela
	glutInitWindowPosition(100, 100); // especifica aonde a janela aparece na tela
	glutCreateWindow("Jogo"); // cria a janela
	init(); // Inicializa valores da tela
	initValoresObjetos(); // Inicializa valores dos objetos do jogo
	escolhe_joy_key(); // Escolhe entre Joystick e Teclado
	glutReshapeFunc(Reshape); // Redimensiona tela
	glutDisplayFunc(display); // Desenha na tela
	glutTimerFunc(10, Timer_Inicio, 1); // Fun��o timer
	glutMainLoop(); // mostra todas as janelas criadas
	return 0;
}

